# Military News Bot
